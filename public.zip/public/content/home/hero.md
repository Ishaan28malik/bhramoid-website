# Hero Section

## Slide 1
title: "Rebuilding Indian Governance from the Ground Up"
subtitle: "Take control of your democracy today"
description: "Advanced leader? Total beginner? Now you can manage governance, engage citizens, and more with comprehensive transparency tools in one secure solution."

## Slide 2
title: "Upgrading Legacy Democracy with Digital Innovation"
subtitle: "Don't trust, verify"
description: "BrahMoID's secure governance platform makes it easier for you to protect and manage your democratic participation with complete transparency."

## Slide 3
title: "Tackling Corruption Through Transparency and Accountability"
subtitle: "Your governance. Your rules. Your future."
description: "Industry-leading transparency, absolute ease of use, and all-in-one connectivity for modern political leadership."
